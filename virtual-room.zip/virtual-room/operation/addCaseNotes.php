<?php
// slingshot to onemedpro handler
require "{$_SERVER['DOCUMENT_ROOT']}/myonemedpro/operation/addCaseNotes.php";
