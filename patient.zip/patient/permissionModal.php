 <div class="modal fade show" id="permission-info" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 id="permission-title">Allow MHA Telemedicine To Use Your Camera and Microphone</h4>
            </div>
            <div class="modal-body"> 
                <p id="permission-body">MHA Telemedicine needs access to your camera and microphone so that other participants can see and hear you. Please close any applications using your camera and microphone.</p>
            </div>
            <div class="modal-footer">
                <button data-dismiss="modal">Dismiss</button>
            </div>
        </div>
    </div>
</div> 
<!-- end modal -->