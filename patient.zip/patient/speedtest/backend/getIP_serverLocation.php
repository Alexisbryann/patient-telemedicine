<?php
///$serverLoc="52.3740,4.8897";
$serverLoc="";

?>